package p3;

public class Main {

	public static void main(String[] args) {
		Pet p1 = new Pet("dog", "Einstein", "woofs");
		System.out.println(p1);

		Pet p2 = new Pet("cat", "Whoopi Goldberg", "meows");
		System.out.println(p2);

	}
}
