package p1;

public class Main {

	public static void main(String[] args) {
		Info in1 = new Info("Raizel", "123 Cherry Rd.", 19, "1-800-2345");
		
		System.out.println(in1);
		
//		in1.setName("Raizel");
//		in1.setAddress("123 Cherry Rd.");
//		in1.setAge(19);
//		in1.setPhoneNumber("1-800-2345");
//		
//		String in1Name = in1.getName();
//		String in1Address = in1.getAddress();
//		int in1Age = in1.getAge();
//		String in1PhoneNumber = in1.getPhoneNumber();
//
//		System.out.println(in1Name);
//		System.out.println(in1Address);
//		System.out.println(in1Age);
//		System.out.println(in1PhoneNumber);
//		
		System.out.println();
		
		Info in2 = new Info("Jeter", "456 Berry Rd.", 18, "1-800-6789");
		
		System.out.println(in2);
		
//		in2.setName("Jeter");
//		in2.setAddress("456 Berry Rd.");
//		in2.setAge(18);
//		in2.setPhoneNumber("1-800-6789");
//		
//		String in2Name = in2.getName();
//		String in2Address = in2.getAddress();
//		int in2Age = in2.getAge();
//		String in2PhoneNumber = in2.getPhoneNumber();
//
//		System.out.println(in2Name);
//		System.out.println(in2Address);
//		System.out.println(in2Age);
//		System.out.println(in2PhoneNumber);
		
	}

}
