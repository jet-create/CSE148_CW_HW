package p1;

import java.util.Arrays;

public class BookBag {
	private Book[] books;
	private int nElems;
	
	public BookBag(int maxSize) {
		books = new Book[maxSize];
		nElems = 0;
		
	}
	
	public void insert(Book book) {
		books[nElems++] = book;
	}
	
	public Book removeByISBN(String isbn) {
		for(int i = 0; i < books.length; i++) {
			if(books[i].getIsbn().equals(isbn)) {
				Book removeBook = books[i];
				books[i] = null;
				return removeBook;
			}
		}
		return null;
	}
	
	public Book searchbyISBN(String isbn) {
		for(int i = 0; i < books.length; i++) {
			if(books[i].getIsbn().equals(isbn)) {
				return books[i];
			}
		}
		return null;
	}
	
	public void display() {
//		System.out.printf("%-20s", "Book name");
//		for(Book book: books) {
//			System.out.println(Arrays.toString(books));
//		}
		System.out.println();
	}
	
	
}
